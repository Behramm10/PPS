#include <iostream>
#include <cmath>

int main() {
    double radius;
    const double pi = 3.14159265358979323846;

    // Input the radius of the circle
    std::cout << "Enter the radius of the circle: ";
    std::cin >> radius;

    // Calculate the area of the circle
    double area = pi * pow(radius, 2);

    // Calculate the perimeter (circumference) of the circle
    double perimeter = 2 * pi * radius;

    // Display the calculated area and perimeter
    std::cout << "Area of the circle: " << area << std::endl;
    std::cout << "Perimeter (Circumference) of the circle: " << perimeter << std::endl;

    return 0;
}
