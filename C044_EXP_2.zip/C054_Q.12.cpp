#include <iostream>
#include <cmath>
using namespace std;

int main() {
    double principal, rate, time, compoundInterest;

    // Input principal amount
    cout << "Enter the principal amount: ";
    cin >> principal;

    // Input annual interest rate (in percentage)
    cout << "Enter the annual interest rate (in percentage): ";
    cin >> rate;

    // Convert rate from percentage to decimal
    rate /= 100.0;

    // Input time period (in years)
    cout << "Enter the time period (in years): ";
    cin >> time;

    // Input number of times interest is compounded per year
    int n;
    cout << "Enter the number of times interest is compounded per year: ";
    cin >> n;

    // Calculate compound interest
    compoundInterest = principal * pow(1 + (rate / n), n * time) - principal;

    // Display the result
    cout << "Compound Interest = " << compoundInterest << endl;

    return 0;
}
