#include <iostream>
using namespace std;

int main() {
    int number, originalNumber, sum = 0;

    // Input a four-digit number
    cout << "Enter a four-digit number: ";
    cin >> number;

    // Store the original number for later reference
    originalNumber = number;

    // Check if the number is a four-digit number
    if (number < 1000 || number > 9999) {
        cout << "Invalid input. Please enter a four-digit number." << endl;
    } else {
        // Calculate the sum of digits
        while (number != 0) {
            int digit = number % 10;
            sum += digit;
            number /= 10;
        }

        // Display the result
        cout << "Sum of digits of " << originalNumber << " is: " << sum << endl;
    }

    return 0;
}
