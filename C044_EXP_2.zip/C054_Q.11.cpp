#include <iostream>
#include <cmath>
using namespace std;

int main() {
    double side1, side2, side3;
    double area;

    // Input the lengths of the three sides
    cout << "Enter the length of side 1: ";
    cin >> side1;
    cout << "Enter the length of side 2: ";
    cin >> side2;
    cout << "Enter the length of side 3: ";
    cin >> side3;

    // Check if the triangle is valid
    bool isValid = (side1 + side2 > side3) && (side1 + side3 > side2) && (side2 + side3 > side1);

    if (isValid) {
        // Calculate the semi-perimeter
        double s = (side1 + side2 + side3) / 2;

        // Calculate the area using Heron's formula
        area = sqrt(s * (s - side1) * (s - side2) * (s - side3));

        // Display the area of the triangle
        cout << "The area of the triangle is: " << area << endl;
    } else {
        cout << "The input sides do not form a valid triangle." << endl;
    }

    return 0;
}
