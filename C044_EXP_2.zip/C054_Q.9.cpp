#include <iostream>
using namespace std;

int main() {
    int number, originalNumber, reversedNumber = 0;

    // Input a four-digit number
    cout << "Enter a four-digit number: ";
    cin >> number;

    // Store the original number for later reference
    originalNumber = number;

    // Check if the number is a four-digit number
    if (number < 1000 || number > 9999) {
        cout << "Invalid input. Please enter a four-digit number." << endl;
    } else {
        // Reverse the digits
        while (number != 0) {
            int digit = number % 10;
            reversedNumber = (reversedNumber * 10) + digit;
            number /= 10;
        }

        // Display the reversed number
        cout << "Reversed number of " << originalNumber << " is: " << reversedNumber << endl;
    }

    return 0;
}
