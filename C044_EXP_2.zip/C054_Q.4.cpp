#include <iostream>

int main() {
    int x, y, z;

    // Input values of x, y, and z
    std::cout << "Enter the value of x: ";
    std::cin >> x;

    std::cout << "Enter the value of y: ";
    std::cin >> y;

    std::cout << "Enter the value of z: ";
    std::cin >> z;

    // Rotate the values
    int temp = x;
    x = y;
    y = z;
    z = temp;

    // Display the rotated values
    std::cout << "After rotating:\n";
    std::cout << "x: " << x << std::endl;
    std::cout << "y: " << y << std::endl;
    std::cout << "z: " << z << std::endl;

    return 0;
}
