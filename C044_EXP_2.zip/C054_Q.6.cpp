#include <iostream>
using namespace std;

int main() {
    double principal, rate, time, simpleInterest;

    // Input principal amount
    cout << "Enter the principal amount: ";
    cin >> principal;

    // Input rate of interest
    cout << "Enter the rate of interest (in percentage): ";
    cin >> rate;

    // Convert rate from percentage to decimal
    rate /= 100.0;

    // Input time period (in years)
    cout << "Enter the time period (in years): ";
    cin >> time;

    // Calculate simple interest
    simpleInterest = (principal * rate * time);

    // Display the result
    cout << "Simple Interest = " << simpleInterest << endl;

    return 0;
}
