#include <iostream>
using namespace std;

int main() {
    double num1, num2, largest;

    // Input two numbers
    cout << "Enter first number: ";
    cin >> num1;
    cout << "Enter second number: ";
    cin >> num2;

    // Find the largest number using the ternary operator
    largest = (num1 > num2) ? num1 : num2;

    // Display the largest number
    cout << "The largest number is: " << largest << endl;

    return 0;
}
