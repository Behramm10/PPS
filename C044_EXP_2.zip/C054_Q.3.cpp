#include <iostream>

int main() {
    int a, b;

    // Input the values of a and b
    std::cout << "Enter the value of a: ";
    std::cin >> a;

    std::cout << "Enter the value of b: ";
    std::cin >> b;

    // Exchange values without using a third variable
    a = a + b;
    b = a - b;
    a = a - b;

    // Display the swapped values
    std::cout << "After swapping:\n";
    std::cout << "a: " << a << std::endl;
    std::cout << "b: " << b << std::endl;

    return 0;
}
