#include <iostream>
#include <string>

int main() {
    // Declare variables to store details
    int age;
    std::string name;
    char gender;
    std::string city;
    double height;

    // Read details from the user
    std::cout << "Enter your name: ";
    std::getline(std::cin, name);

    std::cout << "Enter your age: ";
    std::cin >> age;

    std::cout << "Enter your gender (M/F): ";
    std::cin >> gender;

    std::cin.ignore(); // Ignore the newline character left in the input buffer

    std::cout << "Enter your city: ";
    std::getline(std::cin, city);

    std::cout << "Enter your height (in centimeters): ";
    std::cin >> height;

    // Display the entered details
    std::cout << "\nYour Details:\n";
    std::cout << "Name: " << name << std::endl;
    std::cout << "Age: " << age << std::endl;
    std::cout << "Gender: " << gender << std::endl;
    std::cout << "City: " << city << std::endl;
    std::cout << "Height: " << height << " cm" << std::endl;

    return 0;
}
