#include <iostream>
using namespace std;

int main() {
    double salesAmount, discount, amountToBePaid;

    // Accept the sales amount from the user
    cout << "Enter the sales amount: ";
    cin >> salesAmount;

    // Calculate the discount based on the sales amount
    if (salesAmount > 5000) {
        discount = 0.12 * salesAmount;
    } else {
        discount = 0.07 * salesAmount;
    }

    // Calculate the amount to be paid after the discount
    amountToBePaid = salesAmount - discount;

    // Display the total discount and amount to be paid
    cout << "Total discount: " << discount << endl;
    cout << "Amount to be paid after discount: " << amountToBePaid << endl;

    return 0;
}
