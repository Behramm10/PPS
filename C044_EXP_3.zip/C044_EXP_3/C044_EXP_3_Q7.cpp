#include <iostream>
using namespace std;

int main() {
    char character;

    // Accept the character from the user
    cout << "Enter a character: ";
    cin >> character;

    // Convert the character to lowercase for easier comparison
    character = tolower(character);

    // Check if the character is a vowel or consonant using a switch case
    switch (character) {
        case 'a':
        case 'e':
        case 'i':
        case 'o':
        case 'u':
            cout << "The character is a vowel." << endl;
            break;
        default:
            cout << "The character is a consonant." << endl;
            break;
    }

    return 0;
}

