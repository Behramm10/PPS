#include <iostream>
using namespace std;

int main() {
    char character;

    // Accept the character from the user
    cout << "Enter a character: ";
    cin >> character;

    // Check if the character is a capital letter
    if (character >= 'A' && character <= 'Z') {
        // Convert the capital letter to a small letter
        character = character + 32;
        cout << "The character is a capital letter." << endl;
        cout << "Converted to small letter: " << character << endl;
    }
    // Check if the character is a small letter
    else if (character >= 'a' && character <= 'z') {
        // Convert the small letter to a capital letter
        character = character - 32;
        cout << "The character is a small letter." << endl;
        cout << "Converted to capital letter: " << character << endl;
    }
    // If the character is neither a capital nor a small letter
    else {
        cout << "The character is not a letter." << endl;
    }

    return 0;
}

