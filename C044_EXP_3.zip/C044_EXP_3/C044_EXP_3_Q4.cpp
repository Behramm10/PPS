#include <iostream>
using namespace std;

int main() {
    int number;

    // Accept the number from the user
    cout << "Enter a number: ";
    cin >> number;

    // Check if the number is divisible by 3 and 5
    if (number % 3 == 0 && number % 5 == 0) {
        cout << "BOTH" << endl;
    }
    // Check if the number is divisible by 3 but not by 5
    else if (number % 3 == 0) {
        cout << "THREE" << endl;
    }
    // Check if the number is divisible by 5 but not by 3
    else if (number % 5 == 0) {
        cout << "FIVE" << endl;
    }
    // If the number is not divisible by 3 or 5
    else {
        cout << "NOT" << endl;
    }

    return 0;
}

