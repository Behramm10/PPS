#include <iostream>
using namespace std;

int main() {
    char op;
    double operand1, operand2, result;

    // Accept the arithmetic operator and operands from the user
    cout << "Enter an arithmetic operator (+, -, *, or /): ";
    cin >> op;
    cout << "Enter operand 1: ";
    cin >> operand1;
    cout << "Enter operand 2: ";
    cin >> operand2;

    // Perform the arithmetic operation based on the operator using a switch case
    switch (op) {
        case '+':
            result = operand1 + operand2;
            cout << "Result: " << result << endl;
            break;
        case '-':
            result = operand1 - operand2;
            cout << "Result: " << result << endl;
            break;
        case '*':
            result = operand1 * operand2;
            cout << "Result: " << result << endl;
            break;
        case '/':
            if (operand2 != 0) {
                result = operand1 / operand2;
                cout << "Result: " << result << endl;
            } else {
                cout << "Error: Division by zero is not allowed." << endl;
            }
            break;
        default:
            cout << "Error: Invalid arithmetic operator." << endl;
            break;
    }

    return 0;
}

