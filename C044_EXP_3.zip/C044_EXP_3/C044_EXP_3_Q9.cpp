#include <iostream>
using namespace std;

double calculateTriangleArea(double base, double height) {
    return 0.5 * base * height;
}

double calculateRectangleArea(double length, double width) {
    return length * width;
}

double calculateCircleArea(double radius) {
    return 3.14159 * radius * radius;
}

double calculateSphereArea(double radius) {
    return 4 * 3.14159 * radius * radius;
}

int main() {
    int choice;
    double base, height, length, width, radius;

    do {
        // Display the menu
        cout << "Menu:" << endl;
        cout << "1. Calculate the area of a triangle" << endl;
        cout << "2. Calculate the area of a rectangle" << endl;
        cout << "3. Calculate the area of a circle" << endl;
        cout << "4. Calculate the area of a sphere" << endl;
        cout << "5. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        // Perform the selected operation
        switch (choice) {
            case 1:
                cout << "Enter the base of the triangle: ";
                cin >> base;
                cout << "Enter the height of the triangle: ";
                cin >> height;
                cout << "Area of the triangle: " << calculateTriangleArea(base, height) << endl;
                break;
            case 2:
                cout << "Enter the length of the rectangle: ";
                cin >> length;
                cout << "Enter the width of the rectangle: ";
                cin >> width;
                cout << "Area of the rectangle: " << calculateRectangleArea(length, width) << endl;
                break;
            case 3:
                cout << "Enter the radius of the circle: ";
                cin >> radius;
                cout << "Area of the circle: " << calculateCircleArea(radius) << endl;
                break;
            case 4:
                cout << "Enter the radius of the sphere: ";
                cin >> radius;
                cout << "Area of the sphere: " << calculateSphereArea(radius) << endl;
                break;
            case 5:
                cout << "Exiting the program..." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
        }

        cout << endl;
    } while (choice != 5);

    return 0;
}

