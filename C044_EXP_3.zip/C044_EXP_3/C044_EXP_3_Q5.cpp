#include <iostream>
using namespace std;

int main() {
    double value;

    // Accept the value in nm/ML from the user
    cout << "Enter the value in nm/ML: ";
    cin >> value;

    // Determine the status based on the value
    if (value < 20) {
        cout << "Status: Deficiency" << endl;
    } else if (value >= 20 && value <= 30) {
        cout << "Status: Insufficiency" << endl;
    } else if (value > 30 && value <= 100) {
        cout << "Status: Sufficiency" << endl;
    } else if (value > 100) {
        cout << "Status: Toxicity" << endl;
    }

    return 0;
}

