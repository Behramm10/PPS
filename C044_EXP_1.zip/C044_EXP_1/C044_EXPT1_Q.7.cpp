#include <iostream>
using namespace std;

int main() {
    float s1, s2, s3;

    cout << "Enter the lengths of the three sides of the triangle: ";
    cin >> s1 >> s2 >> s3;

    if (s1 + s2 > s3 && s1 + s3 > s2 && s2 + s3 > s1) {

        if (s1 == s2 && s2 == s3) {
            cout << "This is an equilateral triangle." << endl;
        } else if (s1 == s2 || s1 == s3 || s2 == s3) {
            cout << "This is an isosceles triangle." << endl;
        } else {
            cout << "This is a scalene triangle." << endl;
        }

    } else {
        cout << "This is not a valid triangle." << endl;
    }

    return 0;
}
