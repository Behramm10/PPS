#include <iostream>
using namespace std;

int main() {
    float percent;

    cout << "Enter the percentage marks: ";
    cin >> percent;

    char grade;
    if (percent >= 90) {
        grade = 'A';
    } else if (percent >= 80) {
        grade = 'B';
    } else if (percent >= 65) {
        grade = 'C';
    } else {
        grade = 'D';
    }

    cout << "Grade: " << grade << endl;

    return 0;
}
