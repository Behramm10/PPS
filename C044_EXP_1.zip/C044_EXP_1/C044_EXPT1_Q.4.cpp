#include <iostream>
using namespace std;

int main() {
    int num1 = 6;
    int num2 = 8;

    num2 += 9;
    int num3 = num1 * num2;

    num2 -= num1;

    cout << "n1: " << num1 << endl;
    cout << "n2: " << num2 << endl;
    cout << "n3: " << num3 << endl;

    return 0;
}
