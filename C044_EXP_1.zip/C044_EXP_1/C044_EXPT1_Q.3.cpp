#include <iostream>
using namespace std;

int main() {
    float totalAmount, Budget, returnAmount;

    float milkPrice = 50.0;
    float carrotPrice = 35.0;
    float tomatoPrice = 10.0;

    float milkQuantity, carrotWeight, tomatoWeight;

    cout << "Enter the quantity of milk (in litres): ";
    cin >> milkQuantity;

    cout << "Enter the weight of carrots (in kg): ";
    cin >> carrotWeight;

    cout << "Enter the weight of tomatoes (in kg): ";
    cin >> tomatoWeight;

    totalAmount = (milkPrice * milkQuantity) + (carrotPrice * carrotWeight) + (tomatoPrice * tomatoWeight);

    Budget = 500.0;

    returnAmount = Budget - totalAmount;

    cout << "The shopkeeper will return Rs. " << returnAmount << " to Krishna." << endl;

    return 0;
}
