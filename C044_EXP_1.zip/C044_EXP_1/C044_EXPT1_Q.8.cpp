#include <iostream>
using namespace std;

int main() {
    int num;
    unsigned long fact = 1;
    cout << "Enter a non-negative integer: ";
    cin >> num;

    if (num < 0) {
        cout << "Error: Factorial is not defined for negative numbers." << endl;
    } else {
        for (int i = 1; i <= num; ++i) {
            fact *= i;
        }

        cout << "The factorial of " << num << " is " << fact << endl;
    }

    return 0;
}
