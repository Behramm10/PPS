#include <iostream>
using namespace std;

int main() {
    float len, width, area, perimeter;

    cout << "Enter the length of the rectangle: ";
    cin >> len;

    cout << "Enter the width of the rectangle: ";
    cin >> width;

    area = len * width;
    perimeter = 2 * (len + width);

    cout << "Area of the rectangle: " << area << endl;
    cout << "Perimeter of the rectangle: " << perimeter << endl;

    return 0;
}
